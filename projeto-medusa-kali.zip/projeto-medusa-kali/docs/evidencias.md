# Registro de evidências

> Não publique senhas, cookies, tokens, IPs corporativos ou dados pessoais.

## Identificação

- Data do teste:
- Responsável: Carlos Alexandre Campos Saraiva
- Ambiente: VirtualBox host-only
- IP do Kali:
- IP do alvo:
- Snapshot utilizado:

## Evidência 1: descoberta de serviços

- Comando executado:
- Portas identificadas:
- Arquivo de saída: `nmap-servicos.txt`
- Captura: `../images/nmap.png`

## Evidência 2: FTP

- Objetivo:
- Comando:
- Resultado:
- Validação:
- Captura: `../images/ftp.png`

## Evidência 3: DVWA

- Objetivo:
- Configuração de segurança do DVWA:
- Resultado:
- Captura: `../images/dvwa.png`

## Evidência 4: SMB password spraying

- Objetivo:
- Usuários fictícios testados:
- Quantidade de senhas por rodada: 1
- Resultado:
- Captura: `../images/smb.png`

## Lições aprendidas

- 
- 
- 

## Mitigações priorizadas

1. 
2. 
3. 
