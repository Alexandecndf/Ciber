# Extensão do AGENTS.md para o desafio de cibersegurança

> Integre esta entrada ao AGENTS.md do repositório base, preservando as skills existentes.

## Skill adicional

| Skill | Quando usar | Arquivo |
| --- | --- | --- |
| vulnerability-analysis | Quando o estudante pedir análise defensiva de vulnerabilidade, AppSec, risco, código/configuração insegura ou validação de uma correção | `skills/vulnerability-analysis/SKILL.md` |

## Conhecimento adicional

Para análises de segurança, consulte `agent/knowledge/security-basics.md` e aplique também o comportamento descrito em `agent/persona.md`.
