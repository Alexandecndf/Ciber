# DIO Agent - Mentor de Cibersegurança e AppSec

Especialização educacional do DIO Agent para conduzir análises defensivas de vulnerabilidades com foco em contexto, impacto, probabilidade, severidade, mitigação e validação.

## Objetivo

A proposta é transformar o agente em um mentor de segurança que não começa por comandos. Primeiro ele entende o ativo, exposição, dados envolvidos, ambiente e autorização. Depois organiza a análise e recomenda uma correção segura.

## Especialização criada

A skill `vulnerability-analysis` orienta o agente a:

1. entender o contexto;
2. identificar a vulnerabilidade e evidências;
3. separar vulnerabilidade, ameaça e risco;
4. avaliar impacto sobre confidencialidade, integridade e disponibilidade;
5. estimar probabilidade e severidade com justificativa;
6. propor mitigação priorizada;
7. validar a correção;
8. registrar riscos residuais e próximos passos.

## Arquivos criados ou alterados

```text
dio-agent-cybersecurity/
├── README.md
├── AGENTS.md
├── agent/
│   ├── persona.md
│   └── knowledge/
│       └── security-basics.md
├── skills/
│   └── vulnerability-analysis/
│       ├── SKILL.md
│       └── README.md
├── examples/
│   ├── app_vulnerable.py
│   └── app_fixed.py
└── images/
    └── .gitkeep
```

## Cenário prático: SQL Injection

O exemplo vulnerável demonstra, somente em código local de laboratório, uma consulta SQL construída por concatenação de entrada. O arquivo corrigido usa consulta parametrizada.

### Antes

```python
query = "SELECT id, username FROM users WHERE username = '" + username + "' AND password = '" + password + "'"
```

### Depois

```python
cursor.execute(
    "SELECT id, username FROM users WHERE username = ? AND password = ?",
    (username, password),
)
```

O objetivo não é fornecer payloads de exploração, mas permitir que o agente reconheça a causa raiz, explique o risco e valide a correção.

## Formato padrão da análise

O agente deve produzir:

```text
Contexto
Achado
Evidências
Impacto (C/I/D)
Probabilidade
Severidade
Justificativa
Mitigação
Validação
Risco residual
Referências
```

## Como testar

1. Use o repositório oficial do DIO Agent como base.
2. Copie os arquivos desta especialização para os caminhos equivalentes.
3. Abra a raiz do projeto no harness escolhido.
4. Execute o harness a partir da pasta do projeto, para que os arquivos do agente estejam no contexto.
5. Solicite a revisão de `examples/app_vulnerable.py`.
6. Depois solicite nova análise de `examples/app_fixed.py` e compare os resultados.

Exemplo de prompt defensivo:

```text
Atue como meu mentor de AppSec e analise examples/app_vulnerable.py.
Antes de concluir, identifique o contexto necessário.
Depois apresente o achado no formato da skill vulnerability-analysis,
explique a causa raiz e proponha uma correção segura.
Não preciso de payload de exploração.
```

## Teste de perguntas de contexto

Cenário sugerido:

```text
Tenho um servidor Ubuntu de laboratório acessível pela internet e identifiquei um serviço desatualizado. Quero avaliar o risco.
```

O comportamento esperado é o agente pedir detalhes relevantes antes de prescrever ações, por exemplo: versão, serviço, exposição, dados processados, controles existentes, finalidade e autorização do ambiente.

## Melhoria escolhida

Foi escolhido um **formato padronizado de análise** para facilitar comparação entre achados. Impacto, probabilidade e severidade precisam ter justificativa e não devem ser atribuídos apenas pelo nome da vulnerabilidade.

## Evidências para o portfólio

Adicione em `images/` capturas como:

```text
01-estrutura-projeto.png
02-analise-app-vulnerable.png
03-perguntas-contexto.png
04-correcao-parametrizada.png
05-reanalise-app-fixed.png
06-resultado-padronizado.png
```

Antes de publicar, remova tokens, caminhos pessoais, credenciais e outras informações sensíveis.

## Uso responsável

A skill é defensiva. Testes ativos devem ocorrer somente em sistemas próprios ou explicitamente autorizados. Para alvos reais, o agente deve priorizar confirmação de escopo, orientação de correção e métodos de validação não destrutivos.

## Referências

- DIO Agent: https://github.com/digitalinnovationone/dio-agent
- OWASP Top 10: https://owasp.org/www-project-top-ten/
- MITRE ATT&CK: https://attack.mitre.org/
- CWE: https://cwe.mitre.org/

## Autor

Carlos Alexandre Campos Saraiva
