# Fundamentos de Segurança

## Vulnerabilidade
Fraqueza em software, configuração, processo ou controle que pode contribuir para um incidente quando explorada ou acionada em determinado contexto.

## Ameaça
Circunstância ou agente capaz de explorar uma vulnerabilidade ou causar impacto a um ativo.

## Risco
Combinação contextual entre possibilidade de ocorrência e impacto para o negócio ou ativo. Um nome de vulnerabilidade, isoladamente, não determina todo o risco.

## Tríade CIA

### Confidencialidade
Proteção contra divulgação ou acesso não autorizado.

### Integridade
Proteção contra alteração indevida ou perda de exatidão/confiabilidade.

### Disponibilidade
Garantia de que sistemas e informações necessários estejam acessíveis quando requeridos.

## Boas práticas

- aplicar princípio do menor privilégio;
- manter software suportado e atualizado;
- usar autenticação forte e MFA quando adequado;
- validar entradas e usar APIs seguras;
- preferir consultas parametrizadas para interação com bancos de dados;
- proteger segredos e não armazená-los em código-fonte;
- segmentar redes e restringir exposição;
- manter logs e monitoração;
- testar backups e recuperação;
- realizar testes de segurança somente com autorização e escopo definidos.

## Análise qualitativa

Impacto e probabilidade podem ser classificados como baixo, médio ou alto. A severidade final deve possuir justificativa contextual e ser revisada quando surgirem novas evidências.
