"""Versão didática corrigida com consulta parametrizada."""
import sqlite3


def login(connection, username, password):
    cursor = connection.cursor()
    query = "SELECT id, username FROM users WHERE username = ? AND password = ?"
    return cursor.execute(query, (username, password)).fetchone()
