"""Exemplo didático local: demonstra construção insegura de SQL por concatenação."""
import sqlite3


def login(connection, username, password):
    cursor = connection.cursor()
    query = "SELECT id, username FROM users WHERE username = '" + username + "' AND password = '" + password + "'"
    return cursor.execute(query).fetchone()
